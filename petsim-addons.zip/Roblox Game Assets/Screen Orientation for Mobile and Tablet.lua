game:GetService("RunService").Heartbeat:Connect(function()
	game.Players.LocalPlayer.PlayerGui.ScreenOrientation = Enum.ScreenOrientation.LandscapeLeft
end)