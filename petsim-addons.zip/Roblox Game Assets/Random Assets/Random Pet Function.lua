function RandomPet(TableWithChances, LuckMultiplier)
	local EggInfo = TableWithChances
	local Pets, TotalWeight = {}, 0

	for name, chance in pairs(EggInfo) do
		table.insert(Pets, {name, chance})
	end

	table.sort(Pets, function(a,b)
		return a[2] > b[2]
	end)

	local BaseChance = Pets[1][2] -- this is the most common pet

	for _,v in Pets do
		local Chance = math.min(v[2] * LuckMultiplier, BaseChance) -- so if the easiest pet is 70%, all pets will go towards 70% 
		TotalWeight += Chance
		v[2] = Chance
	end

	local Chance = Random.new():NextNumber(0,TotalWeight)

	local Counter = 0
	for _,v in Pets do	
		Counter += v[2]

		if Counter >= Chance then
			return v[1]
		end
	end
end