--[[

HOW TO USE MY MESSAGE SYSTEM??

write new variable in you script (IMPORTANT, YOU SHOULD USE THIS MODULE ONLY FOR LOCAL SCRIPT!!): local Message = require(game.ReplicateStorage.Modules.Message)

now you can call basic message, like to say you have collected somthing: Message.New(Player, "YOu Collect A Coin!")

if you want to make a choose (yes/no) you should do this:

local suc = Message.New(Player, "Are You Sure Want To Buy It?", true) -- true will call a special function in module script

if suc then
print("yes")
else
print("no")
end

JOIN TO MY TELEGRAM CHANNEL - t.me/krovatniy_gang

FOR ANY ISSUE/BUGS DM TO @krovatniy (discord) @KPoBaTHbIU telegram

]]