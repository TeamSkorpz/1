local plr = game:GetService("Players").LocalPlayer
local plrGui = plr:WaitForChild("PlayerGui")
local BASE_SIZE = 2000 -- Adjust this

local function updateStroke(uiStroke)
	local initialStrokeThickness = uiStroke.Thickness
	local camera = game:GetService("Workspace").CurrentCamera

	local function updateStrokeThickness()
		uiStroke.Thickness = initialStrokeThickness * camera.ViewportSize.X / BASE_SIZE
	end

	camera:GetPropertyChangedSignal("ViewportSize"):Connect(updateStrokeThickness)
	updateStrokeThickness()
end

for i, descendant in pairs(plrGui:GetDescendants()) do
	if descendant:IsA("UIStroke") then
		updateStroke(descendant)
	end
end

plrGui.DescendantAdded:Connect(function(descendant)
	if descendant.Name == "UIStroke" then
		updateStroke(descendant)
	end
end)